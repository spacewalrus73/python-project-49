#!/usr/bin/env python3
from brain_games.games.gcd import push


def main():
    push()
