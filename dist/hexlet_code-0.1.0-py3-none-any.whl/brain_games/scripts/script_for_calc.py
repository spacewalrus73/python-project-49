#!/usr/bin/env python3
from brain_games.games.calc import push


def main():
    push()
