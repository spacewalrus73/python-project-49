# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.script_for_calc:main',
                     'brain-even = brain_games.scripts.script_for_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/spacewalrus73/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/spacewalrus73/python-project-49/actions)\n<a href="https://codeclimate.com/github/spacewalrus73/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3341c6741e9a9d6ff12a/maintainability" /></a>\n\'video how brain-even works: https://asciinema.org/a/d95VfUCy797tji8U3E4eiTyMq\'\n',
    'author': 'Daniil Balabanov',
    'author_email': 'spacewalrus@bk.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
