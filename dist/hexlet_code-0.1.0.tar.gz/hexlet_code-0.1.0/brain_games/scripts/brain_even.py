#!/usr/bin/env python3
from games.even import push


def main():
    push()


if __name__ == '__main__':
    main()