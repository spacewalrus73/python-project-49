#!/usr/bin/env python3
from brain_games.even import is_even


def main():
    is_even()
