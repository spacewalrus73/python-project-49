### Hexlet tests and linter status:
[![Actions Status](https://github.com/spacewalrus73/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/spacewalrus73/python-project-49/actions)
<a href="https://codeclimate.com/github/spacewalrus73/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3341c6741e9a9d6ff12a/maintainability" /></a>
